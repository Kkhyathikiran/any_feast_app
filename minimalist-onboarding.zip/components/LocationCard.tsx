import React from 'react';
import { LocationOption } from '../types';
import { CheckCircle2 } from 'lucide-react';

interface LocationCardProps {
  location: LocationOption;
  isSelected: boolean;
  onSelect: (id: string) => void;
}

export const LocationCard: React.FC<LocationCardProps> = ({ location, isSelected, onSelect }) => {
  return (
    <div
      onClick={() => onSelect(location.id)}
      className={`
        relative group cursor-pointer overflow-hidden
        rounded-xl border transition-all duration-300
        ${isSelected 
          ? 'border-black bg-white shadow-md ring-1 ring-black' 
          : 'border-black bg-white hover:bg-gray-50'
        }
      `}
    >
      {/* Image Container */}
      <div className="h-32 w-full overflow-hidden border-b border-black">
        <img
          src={location.imageUrl}
          alt={location.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
      </div>

      {/* Content */}
      <div className={`p-4 flex items-center justify-between ${isSelected ? 'bg-white' : 'bg-gray-50'}`}>
        <span className="font-semibold text-lg text-black">{location.name}</span>
        
        {isSelected ? (
          <CheckCircle2 className="w-6 h-6 text-black" />
        ) : (
          <div className="w-6 h-6 rounded-full border border-black opacity-30 group-hover:opacity-100 transition-opacity" />
        )}
      </div>
    </div>
  );
};