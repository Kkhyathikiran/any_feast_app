import React from 'react';
import { ChevronDown } from 'lucide-react';

interface Option {
  value: string | number;
  label: string;
}

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  options: Option[];
  error?: string;
}

export const Select: React.FC<SelectProps> = ({ label, options, error, className = '', ...props }) => {
  return (
    <div className="flex flex-col gap-1.5 w-full">
      <label className="text-sm font-medium text-black ml-1">
        {label}
      </label>
      <div className="relative">
        <select
          className={`
            w-full px-4 py-3 bg-white border border-black rounded-lg 
            text-black appearance-none outline-none transition-all
            focus:ring-1 focus:ring-black/50
            disabled:opacity-50 cursor-pointer
            ${error ? 'border-red-500 focus:ring-red-500' : ''}
            ${className}
          `}
          {...props}
        >
          <option value="" disabled>Select {label}</option>
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-black/50">
          <ChevronDown size={18} />
        </div>
      </div>
      {error && (
        <span className="text-xs text-red-500 ml-1">
          {error}
        </span>
      )}
    </div>
  );
};