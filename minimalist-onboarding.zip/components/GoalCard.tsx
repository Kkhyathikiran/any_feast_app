import React from 'react';
import { GoalOption } from '../types';
import { CheckCircle2 } from 'lucide-react';

interface GoalCardProps {
  goal: GoalOption;
  isSelected: boolean;
  onSelect: (id: string) => void;
}

export const GoalCard: React.FC<GoalCardProps> = ({ goal, isSelected, onSelect }) => {
  return (
    <div
      onClick={() => onSelect(goal.id)}
      className={`
        relative group cursor-pointer overflow-hidden
        rounded-xl border transition-all duration-300
        ${isSelected 
          ? 'border-black bg-white shadow-md ring-1 ring-black' 
          : 'border-black bg-white hover:bg-gray-50'
        }
      `}
    >
      {/* Image Container */}
      <div className="h-40 w-full overflow-hidden border-b border-black">
        <img
          src={goal.imageUrl}
          alt={goal.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {/* Overlay for better text readability if needed, though we put text below */}
      </div>

      {/* Content */}
      <div className={`p-5 flex items-center justify-between ${isSelected ? 'bg-white' : 'bg-gray-50'}`}>
        <span className="font-bold text-lg text-black tracking-tight">{goal.title}</span>
        
        {isSelected ? (
          <CheckCircle2 className="w-6 h-6 text-black" />
        ) : (
          <div className="w-6 h-6 rounded-full border border-black opacity-30 group-hover:opacity-100 transition-opacity" />
        )}
      </div>
    </div>
  );
};