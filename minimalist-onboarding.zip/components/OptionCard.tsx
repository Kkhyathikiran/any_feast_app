import React from 'react';

interface OptionCardProps {
  label: string;
  isSelected: boolean;
  onSelect: () => void;
  className?: string;
}

export const OptionCard: React.FC<OptionCardProps> = ({ label, isSelected, onSelect, className = '' }) => {
  return (
    <div
      onClick={onSelect}
      className={`
        cursor-pointer rounded-lg border px-4 py-3 text-center transition-all duration-200
        flex items-center justify-center font-medium
        ${isSelected
          ? 'border-black bg-white ring-1 ring-black shadow-sm text-black'
          : 'border-black bg-white hover:bg-gray-50 text-gray-700'
        }
        ${className}
      `}
    >
      {label}
    </div>
  );
};