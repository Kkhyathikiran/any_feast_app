import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'text';
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  className = '', 
  ...props 
}) => {
  if (variant === 'text') {
    return (
      <button 
        className={`text-sm font-medium text-black underline-offset-4 hover:underline disabled:opacity-50 ${className}`}
        {...props}
      >
        {children}
      </button>
    );
  }

  return (
    <button
      className={`
        w-full py-3.5 px-6 
        bg-white border border-black rounded-lg
        text-black font-semibold text-base
        transform active:scale-[0.98] transition-transform duration-100 ease-in-out
        hover:bg-gray-50
        disabled:opacity-50 disabled:cursor-not-allowed
        flex items-center justify-center
        ${className}
      `}
      {...props}
    >
      {children}
    </button>
  );
};