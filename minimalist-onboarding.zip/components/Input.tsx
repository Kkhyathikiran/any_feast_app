import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}

export const Input: React.FC<InputProps> = ({ label, error, className = '', ...props }) => {
  return (
    <div className="flex flex-col gap-1.5 w-full">
      <label className="text-sm font-medium text-black ml-1">
        {label}
      </label>
      <input
        className={`
          w-full px-4 py-3 bg-white border border-black rounded-lg 
          text-black placeholder-gray-500 outline-none transition-all
          focus:ring-1 focus:ring-black/50
          disabled:opacity-50
          ${error ? 'border-red-500 focus:ring-red-500' : ''}
          ${className}
        `}
        {...props}
      />
      {error && (
        <span className="text-xs text-red-500 ml-1">
          {error}
        </span>
      )}
    </div>
  );
};