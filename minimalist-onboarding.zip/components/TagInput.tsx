import React, { useState, KeyboardEvent } from 'react';
import { X } from 'lucide-react';

interface TagInputProps {
  label: string;
  placeholder?: string;
  tags: string[];
  onTagsChange: (tags: string[]) => void;
  disabled?: boolean;
}

export const TagInput: React.FC<TagInputProps> = ({ 
  label, 
  placeholder, 
  tags, 
  onTagsChange,
  disabled = false
}) => {
  const [inputValue, setInputValue] = useState('');

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' || e.key === ',') {
      e.preventDefault();
      addTag();
    }
  };

  const addTag = () => {
    const trimmed = inputValue.trim();
    if (trimmed && !tags.includes(trimmed)) {
      onTagsChange([...tags, trimmed]);
      setInputValue('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    onTagsChange(tags.filter(tag => tag !== tagToRemove));
  };

  return (
    <div className="flex flex-col gap-2 w-full">
      <label className="text-sm font-medium text-black ml-1">
        {label}
      </label>
      
      <div className={`
        min-h-[50px] w-full px-3 py-2 bg-white border border-black rounded-lg 
        transition-all flex flex-wrap gap-2 items-center
        ${disabled ? 'opacity-50 cursor-not-allowed bg-gray-50' : 'focus-within:ring-1 focus-within:ring-black/50'}
      `}>
        {tags.map((tag) => (
          <span key={tag} className="inline-flex items-center gap-1 bg-black text-white text-sm px-2 py-1 rounded-md animate-in zoom-in-50 duration-200">
            {tag}
            <button 
              type="button"
              onClick={() => !disabled && removeTag(tag)}
              className="hover:text-gray-300"
            >
              <X size={14} />
            </button>
          </span>
        ))}
        
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          onBlur={addTag}
          placeholder={tags.length === 0 ? placeholder : ''}
          disabled={disabled}
          className="flex-1 min-w-[120px] outline-none bg-transparent text-black placeholder-gray-500 py-1"
        />
      </div>
    </div>
  );
};