import React, { useState } from 'react';
import { LoginScreen } from './screens/LoginScreen';
import { LocationScreen } from './screens/LocationScreen';
import { AgeScreen } from './screens/AgeScreen';
import { BmiScreen } from './screens/BmiScreen';
import { GoalScreen } from './screens/GoalScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { DietScreen } from './screens/DietScreen';
import { CongratsScreen } from './screens/CongratsScreen';
import { AppStep } from './types';

const App: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<AppStep>('login');

  const handleNext = (nextStep: AppStep) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setCurrentStep(nextStep);
  };

  const handleFinish = () => {
    // Final action logic here (e.g. redirect to real dashboard)
    console.log("Navigating to actual dashboard...");
    alert("Demo Complete! Redirecting to Dashboard...");
    // Reset for demo purposes
    setCurrentStep('login');
  };

  const getStepTitle = () => {
    switch (currentStep) {
      case 'login': return 'Step 1 of 8';
      case 'location': return 'Step 2 of 8';
      case 'age': return 'Step 3 of 8';
      case 'bmi': return 'Step 4 of 8';
      case 'goal': return 'Step 5 of 8';
      case 'settings': return 'Step 6 of 8';
      case 'diet': return 'Step 7 of 8';
      case 'congrats': return 'Step 8 of 8';
      default: return '';
    }
  };

  return (
    <div className="min-h-screen w-full bg-white flex flex-col font-sans">
      {/* Header */}
      <div className="w-full p-6 flex justify-between items-center border-b border-gray-100 sticky top-0 bg-white/80 backdrop-blur-md z-10">
        <div className="font-bold text-xl tracking-tight">App.</div>
        <div className={`text-xs font-medium px-3 py-1 rounded-full border border-black transition-colors duration-300 ${currentStep === 'congrats' ? 'bg-black text-white' : 'bg-white text-black'}`}>
          {currentStep === 'congrats' ? 'Completed' : getStepTitle()}
        </div>
      </div>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col items-center justify-start w-full">
        {currentStep === 'login' && (
          <LoginScreen onLoginSuccess={() => handleNext('location')} />
        )}
        {currentStep === 'location' && (
          <LocationScreen onNext={() => handleNext('age')} />
        )}
        {currentStep === 'age' && (
          <AgeScreen onNext={() => handleNext('bmi')} />
        )}
        {currentStep === 'bmi' && (
          <BmiScreen onNext={() => handleNext('goal')} />
        )}
        {currentStep === 'goal' && (
          <GoalScreen onNext={() => handleNext('settings')} />
        )}
        {currentStep === 'settings' && (
          <SettingsScreen onNext={() => handleNext('diet')} />
        )}
        {currentStep === 'diet' && (
          <DietScreen onFinish={() => handleNext('congrats')} />
        )}
        {currentStep === 'congrats' && (
          <CongratsScreen onGoToDashboard={handleFinish} />
        )}
      </main>

      {/* Footer */}
      <footer className="w-full p-6 text-center text-xs text-gray-300">
        &copy; 2024 Design System Demo
      </footer>
    </div>
  );
};

export default App;