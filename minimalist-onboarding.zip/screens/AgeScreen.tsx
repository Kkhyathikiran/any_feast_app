import React, { useState, useMemo } from 'react';
import { Select } from '../components/Select';
import { Button } from '../components/Button';
import { Calendar } from 'lucide-react';

interface AgeScreenProps {
  onNext: () => void;
}

export const AgeScreen: React.FC<AgeScreenProps> = ({ onNext }) => {
  const [day, setDay] = useState('');
  const [month, setMonth] = useState('');
  const [year, setYear] = useState('');
  const [age, setAge] = useState<{ years: number; months: number } | null>(null);

  // Generate options
  const days = useMemo(() => Array.from({ length: 31 }, (_, i) => ({ value: i + 1, label: `${i + 1}` })), []);
  const months = useMemo(() => [
    { value: 0, label: 'January' }, { value: 1, label: 'February' },
    { value: 2, label: 'March' }, { value: 3, label: 'April' },
    { value: 4, label: 'May' }, { value: 5, label: 'June' },
    { value: 6, label: 'July' }, { value: 7, label: 'August' },
    { value: 8, label: 'September' }, { value: 9, label: 'October' },
    { value: 10, label: 'November' }, { value: 11, label: 'December' }
  ], []);
  const currentYear = new Date().getFullYear();
  const years = useMemo(() => Array.from({ length: 100 }, (_, i) => ({ 
    value: currentYear - i, 
    label: `${currentYear - i}` 
  })), [currentYear]);

  const handleCalculate = () => {
    if (!day || !month || !year) return;

    const today = new Date();
    const birthDate = new Date(parseInt(year), parseInt(month), parseInt(day));
    
    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    
    if (months < 0 || (months === 0 && today.getDate() < birthDate.getDate())) {
      years--;
      months += 12;
    }

    setAge({ years, months });
  };

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto px-6 py-8 animate-in fade-in slide-in-from-right-8 duration-700">
      <div className="text-center mb-8">
        <div className="w-12 h-12 bg-white rounded-full border border-black flex items-center justify-center mx-auto mb-4">
          <Calendar className="text-black" size={24} />
        </div>
        <h2 className="text-2xl font-bold text-black mb-2">Age Calculator</h2>
        <p className="text-gray-600">
          Enter your date of birth to calculate your exact age.
        </p>
      </div>

      <div className="w-full space-y-4 mb-8">
        <div className="grid grid-cols-2 gap-4">
          <Select 
            label="Day" 
            options={days} 
            value={day} 
            onChange={(e) => setDay(e.target.value)} 
          />
          <Select 
            label="Year" 
            options={years} 
            value={year} 
            onChange={(e) => setYear(e.target.value)} 
          />
        </div>
        <Select 
          label="Month" 
          options={months} 
          value={month} 
          onChange={(e) => setMonth(e.target.value)} 
        />
      </div>

      <div className="w-full space-y-4">
        <Button onClick={handleCalculate} disabled={!day || !month || !year}>
          Calculate Age
        </Button>

        {age !== null && (
          <div className="w-full mt-6 bg-white border border-black rounded-xl p-6 text-center animate-in zoom-in-95 duration-300">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-gray-500 mb-2">Your Result</h3>
            <p className="text-3xl font-bold text-black">
              {age.years} <span className="text-lg font-medium text-gray-600">years</span>
            </p>
            {age.months > 0 && (
              <p className="text-base text-gray-600 mt-1">
                & {age.months} months
              </p>
            )}
            <div className="mt-6 pt-2">
              <Button onClick={onNext}>
                Check My BMI
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};