import React from 'react';
import { Button } from '../components/Button';
import { PartyPopper, CheckCircle2, ArrowRight } from 'lucide-react';

interface CongratsScreenProps {
  onGoToDashboard: () => void;
}

export const CongratsScreen: React.FC<CongratsScreenProps> = ({ onGoToDashboard }) => {
  return (
    <div className="flex flex-col items-center justify-center w-full max-w-md mx-auto px-6 py-12 animate-in zoom-in-95 duration-700 min-h-[70vh]">
      
      <div className="relative mb-8 group">
        <div className="w-28 h-28 bg-black rounded-full flex items-center justify-center shadow-xl transform transition-transform duration-500 group-hover:rotate-12">
           <PartyPopper className="text-white animate-bounce" size={48} strokeWidth={1.5} />
        </div>
        <div className="absolute -bottom-2 -right-2 bg-white rounded-full p-1.5 border border-black shadow-sm">
          <CheckCircle2 className="text-green-500 fill-white" size={32} />
        </div>
      </div>

      <h1 className="text-4xl font-extrabold text-black mb-4 text-center tracking-tight">
        Congratulations!
      </h1>
      
      <p className="text-gray-600 text-center text-lg mb-10 leading-relaxed max-w-xs">
        Your profile is complete and your personalized diet plan is ready.
      </p>

      <div className="w-full space-y-6">
        {/* Summary Card */}
        <div className="p-5 border border-black rounded-xl bg-gray-50 flex flex-col gap-3 shadow-sm">
           <h3 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-1">Your Plan</h3>
           <div className="flex justify-between items-center">
             <span className="text-gray-700 font-medium">Diet Status</span>
             <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full border border-green-200">ACTIVE</span>
           </div>
           <div className="w-full h-px bg-gray-200" />
           <div className="flex justify-between items-center">
             <span className="text-gray-700 font-medium">Next Meal</span>
             <span className="font-bold text-black">Evening Snack (4:00 PM)</span>
           </div>
        </div>

        <Button onClick={onGoToDashboard} className="h-14 text-lg shadow-lg hover:shadow-xl transition-all">
          Go to Dashboard <ArrowRight className="ml-2 w-5 h-5" />
        </Button>
      </div>
    </div>
  );
};