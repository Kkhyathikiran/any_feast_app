import React, { useState } from 'react';
import { Input } from '../components/Input';
import { Select } from '../components/Select';
import { Button } from '../components/Button';
import { BmiUnit, BmiResult } from '../types';
import { Activity } from 'lucide-react';

interface BmiScreenProps {
  onNext: () => void;
}

export const BmiScreen: React.FC<BmiScreenProps> = ({ onNext }) => {
  const [unit, setUnit] = useState<BmiUnit>('metric');
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [result, setResult] = useState<BmiResult | null>(null);

  const calculateBmi = () => {
    const h = parseFloat(height);
    const w = parseFloat(weight);

    if (isNaN(h) || isNaN(w) || h <= 0 || w <= 0) return;

    let bmi = 0;

    if (unit === 'metric') {
      // Metric: weight (kg) / [height (m)]^2
      // Input height is usually in cm, so divide by 100
      bmi = w / Math.pow(h / 100, 2);
    } else {
      // Imperial: 703 x weight (lbs) / [height (in)]^2
      bmi = 703 * w / Math.pow(h, 2);
    }

    let category = '';
    if (bmi < 18.5) category = 'Underweight';
    else if (bmi < 24.9) category = 'Normal';
    else if (bmi < 29.9) category = 'Overweight';
    else category = 'Obese';

    setResult({ bmi: parseFloat(bmi.toFixed(1)), category });
  };

  const unitOptions = [
    { value: 'metric', label: 'Metric (cm, kg)' },
    { value: 'imperial', label: 'Imperial (in, lb)' },
  ];

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Normal': return 'text-green-600';
      case 'Overweight': return 'text-orange-500';
      case 'Obese': return 'text-red-500';
      default: return 'text-blue-500';
    }
  };

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto px-6 py-8 animate-in fade-in slide-in-from-right-8 duration-700">
      <div className="text-center mb-8">
        <div className="w-12 h-12 bg-white rounded-full border border-black flex items-center justify-center mx-auto mb-4">
          <Activity className="text-black" size={24} />
        </div>
        <h2 className="text-2xl font-bold text-black mb-2">BMI Calculator</h2>
        <p className="text-gray-600">
          Check your Body Mass Index using your height and weight.
        </p>
      </div>

      <div className="w-full space-y-5 mb-8">
        <Select
          label="Unit System"
          options={unitOptions}
          value={unit}
          onChange={(e) => {
            setUnit(e.target.value as BmiUnit);
            setHeight('');
            setWeight('');
            setResult(null);
          }}
        />

        <div className="grid grid-cols-2 gap-4">
          <Input
            label={`Height (${unit === 'metric' ? 'cm' : 'in'})`}
            type="number"
            placeholder={unit === 'metric' ? '175' : '69'}
            value={height}
            onChange={(e) => setHeight(e.target.value)}
          />
          <Input
            label={`Weight (${unit === 'metric' ? 'kg' : 'lb'})`}
            type="number"
            placeholder={unit === 'metric' ? '70' : '150'}
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
          />
        </div>
      </div>

      <div className="w-full space-y-4">
        <Button onClick={calculateBmi} disabled={!height || !weight}>
          Calculate BMI
        </Button>

        {result && (
          <div className="w-full mt-6 bg-white border border-black rounded-xl p-6 text-center animate-in zoom-in-95 duration-300">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-gray-500 mb-2">Your BMI</h3>
            <p className="text-4xl font-bold text-black mb-1">
              {result.bmi}
            </p>
            <p className={`text-lg font-medium ${getCategoryColor(result.category)}`}>
              {result.category}
            </p>
            
            <div className="mt-6 pt-2">
              <Button onClick={onNext}>
                Set My Goal
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};