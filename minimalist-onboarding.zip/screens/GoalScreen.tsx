import React, { useState } from 'react';
import { GoalCard } from '../components/GoalCard';
import { GoalOption } from '../types';
import { Target } from 'lucide-react';

const GOALS: GoalOption[] = [
  {
    id: 'loss',
    title: 'Weight Loss',
    imageUrl: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'maintain',
    title: 'Maintain Weight',
    imageUrl: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'muscle',
    title: 'Build Muscles',
    imageUrl: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=800&q=80',
  },
];

interface GoalScreenProps {
  onNext: () => void;
}

export const GoalScreen: React.FC<GoalScreenProps> = ({ onNext }) => {
  const [selectedGoalId, setSelectedGoalId] = useState<string | null>(null);

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto px-6 py-8 animate-in fade-in slide-in-from-right-8 duration-700">
      <div className="text-center mb-8">
        <div className="w-12 h-12 bg-white rounded-full border border-black flex items-center justify-center mx-auto mb-4">
          <Target className="text-black" size={24} />
        </div>
        <h2 className="text-2xl font-bold text-black mb-2">What is your goal?</h2>
        <p className="text-gray-600">
          Select the objective that best matches your fitness journey.
        </p>
      </div>

      <div className="w-full grid grid-cols-1 gap-5 mb-8">
        {GOALS.map((goal) => (
          <GoalCard
            key={goal.id}
            goal={goal}
            isSelected={selectedGoalId === goal.id}
            onSelect={setSelectedGoalId}
          />
        ))}
      </div>

      {selectedGoalId && (
        <div className="w-full animate-in fade-in duration-300">
          <button 
            onClick={onNext}
            className="w-full py-4 bg-black text-white rounded-lg font-medium hover:bg-gray-800 transition-colors"
          >
            Continue
          </button>
        </div>
      )}
    </div>
  );
};