import React, { useState, useMemo } from 'react';
import { Select } from '../components/Select';
import { OptionCard } from '../components/OptionCard';
import { Button } from '../components/Button';
import { Settings2 } from 'lucide-react';

interface SettingsScreenProps {
  onNext: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ onNext }) => {
  const [targetWeight, setTargetWeight] = useState('');
  const [reductionSpeed, setReductionSpeed] = useState('');
  const [activityLevel, setActivityLevel] = useState('');

  // Generate weight options (40kg to 150kg)
  const weightOptions = useMemo(() => 
    Array.from({ length: 111 }, (_, i) => ({ 
      value: i + 40, 
      label: `${i + 40} kg` 
    })), 
  []);

  const reductionSpeeds = ['Slow & Steady', 'Moderate', 'Aggressive', 'Maximum'];
  const activityLevels = ['Light', 'Moderate', 'Intensive'];

  const isFormComplete = targetWeight && reductionSpeed && activityLevel;

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto px-6 py-8 animate-in fade-in slide-in-from-right-8 duration-700 pb-20">
      <div className="text-center mb-8">
        <div className="w-12 h-12 bg-white rounded-full border border-black flex items-center justify-center mx-auto mb-4">
          <Settings2 className="text-black" size={24} />
        </div>
        <h2 className="text-2xl font-bold text-black mb-2">Final Details</h2>
        <p className="text-gray-600">
          Let's personalize your plan.
        </p>
      </div>

      <div className="w-full space-y-10">
        
        {/* Section 1: Target Weight */}
        <section className="space-y-3">
          <h3 className="text-lg font-semibold text-black">Set Your Target Weight</h3>
          <Select
            label="Target Weight"
            options={weightOptions}
            value={targetWeight}
            onChange={(e) => setTargetWeight(e.target.value)}
          />
        </section>

        {/* Section 2: Reduction Speed */}
        <section className="space-y-3">
          <h3 className="text-lg font-semibold text-black">How fast to reduce?</h3>
          <div className="grid grid-cols-2 gap-3">
            {reductionSpeeds.map((speed) => (
              <OptionCard
                key={speed}
                label={speed}
                isSelected={reductionSpeed === speed}
                onSelect={() => setReductionSpeed(speed)}
              />
            ))}
          </div>
        </section>

        {/* Section 3: Activity Level */}
        <section className="space-y-3">
          <h3 className="text-lg font-semibold text-black">How active are you?</h3>
          <div className="grid grid-cols-3 gap-3">
            {activityLevels.map((level) => (
              <OptionCard
                key={level}
                label={level}
                isSelected={activityLevel === level}
                onSelect={() => setActivityLevel(level)}
              />
            ))}
          </div>
        </section>

        {/* Section 4: Motivation */}
        <section className="w-full relative rounded-xl overflow-hidden border border-black h-48 group">
           <img 
            src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&w=800&q=80" 
            alt="Motivation" 
            className="absolute inset-0 w-full h-full object-cover brightness-[0.7] group-hover:scale-105 transition-transform duration-700"
           />
           <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
             <p className="text-white font-bold text-lg leading-relaxed italic drop-shadow-md">
               "Discipline is choosing what you want most over what you want now."
             </p>
           </div>
        </section>

        <div className="pt-4">
          <Button onClick={onNext} disabled={!isFormComplete}>
            Set Up My Diet
          </Button>
        </div>
      </div>
    </div>
  );
};