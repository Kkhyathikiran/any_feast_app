import React, { useState } from 'react';
import { Select } from '../components/Select';
import { Button } from '../components/Button';
import { TagInput } from '../components/TagInput';
import { Utensils, ChevronDown, ChevronUp } from 'lucide-react';

interface DietScreenProps {
  onFinish: () => void;
}

export const DietScreen: React.FC<DietScreenProps> = ({ onFinish }) => {
  const [activeSection, setActiveSection] = useState<number>(0);
  
  // State
  const [dietType, setDietType] = useState('');
  const [noAllergies, setNoAllergies] = useState(false);
  const [allergies, setAllergies] = useState<string[]>([]);
  const [dislikes, setDislikes] = useState<string[]>([]);
  const [cuisine, setCuisine] = useState('');

  const dietOptions = [
    { value: 'vegetarian', label: 'Vegetarian' },
    { value: 'non-vegetarian', label: 'Non-Vegetarian' },
    { value: 'vegan', label: 'Vegan' },
    { value: 'jain', label: 'Jain' },
    { value: 'eggetarian', label: 'Eggetarian' },
  ];

  const cuisineOptions = [
    { value: 'indian', label: 'Indian' },
    { value: 'south-indian', label: 'South Indian' },
    { value: 'north-indian', label: 'North Indian' },
    { value: 'italian', label: 'Italian' },
    { value: 'chinese', label: 'Chinese' },
    { value: 'continental', label: 'Continental' },
    { value: 'mediterranean', label: 'Mediterranean' },
  ];

  const toggleSection = (index: number) => {
    setActiveSection(activeSection === index ? -1 : index);
  };

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto px-6 py-8 animate-in fade-in slide-in-from-right-8 duration-700 pb-20">
      
      {/* Header Image */}
      <div className="w-full h-48 rounded-xl overflow-hidden border border-black mb-8 relative shadow-sm">
        <img 
          src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80" 
          alt="Healthy Diet Bowl" 
          className="w-full h-full object-cover"
        />
        <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-lg border border-black flex items-center gap-2">
          <Utensils size={16} />
          <span className="text-xs font-bold">Diet Preferences</span>
        </div>
      </div>

      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-black mb-2">Set My Diet</h2>
        <p className="text-gray-600">
          Tell us what you like to eat so we can curate the perfect meal plan.
        </p>
      </div>

      <div className="w-full space-y-4">
        
        {/* 1. Diet Type */}
        <div className={`border border-black rounded-xl overflow-hidden transition-all duration-300 ${activeSection === 0 ? 'bg-white shadow-sm' : 'bg-gray-50'}`}>
          <button onClick={() => toggleSection(0)} className="w-full px-5 py-4 flex items-center justify-between font-semibold text-left">
            <span>1. Diet Preference</span>
            {activeSection === 0 ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </button>
          
          {activeSection === 0 && (
            <div className="px-5 pb-5 pt-0 animate-in slide-in-from-top-2 duration-200">
              <Select
                label="Select your diet preference"
                options={dietOptions}
                value={dietType}
                onChange={(e) => setDietType(e.target.value)}
              />
            </div>
          )}
        </div>

        {/* 2. Food Allergies */}
        <div className={`border border-black rounded-xl overflow-hidden transition-all duration-300 ${activeSection === 1 ? 'bg-white shadow-sm' : 'bg-gray-50'}`}>
          <button onClick={() => toggleSection(1)} className="w-full px-5 py-4 flex items-center justify-between font-semibold text-left">
            <span>2. Food Allergies</span>
            {activeSection === 1 ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </button>
          
          {activeSection === 1 && (
            <div className="px-5 pb-5 pt-0 animate-in slide-in-from-top-2 duration-200">
              <div className="mb-4 flex items-center gap-2">
                <input 
                  type="checkbox" 
                  id="no-allergies" 
                  checked={noAllergies} 
                  onChange={(e) => {
                    setNoAllergies(e.target.checked);
                    if (e.target.checked) setAllergies([]);
                  }}
                  className="w-5 h-5 rounded border-black text-black focus:ring-black"
                />
                <label htmlFor="no-allergies" className="text-sm text-gray-700 font-medium">I have no food allergies</label>
              </div>

              {!noAllergies && (
                <TagInput
                  label="Allergies (Type & Press Enter)"
                  placeholder="e.g. Peanuts, Gluten"
                  tags={allergies}
                  onTagsChange={setAllergies}
                  disabled={noAllergies}
                />
              )}
            </div>
          )}
        </div>

        {/* 3. Dislikes */}
        <div className={`border border-black rounded-xl overflow-hidden transition-all duration-300 ${activeSection === 2 ? 'bg-white shadow-sm' : 'bg-gray-50'}`}>
          <button onClick={() => toggleSection(2)} className="w-full px-5 py-4 flex items-center justify-between font-semibold text-left">
            <span>3. Ingredients You Dislike</span>
            {activeSection === 2 ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </button>
          
          {activeSection === 2 && (
            <div className="px-5 pb-5 pt-0 animate-in slide-in-from-top-2 duration-200">
              <TagInput
                label="Dislikes (Optional)"
                placeholder="e.g. Mushrooms, Olives"
                tags={dislikes}
                onTagsChange={setDislikes}
              />
            </div>
          )}
        </div>

        {/* 4. Cuisine */}
        <div className={`border border-black rounded-xl overflow-hidden transition-all duration-300 ${activeSection === 3 ? 'bg-white shadow-sm' : 'bg-gray-50'}`}>
          <button onClick={() => toggleSection(3)} className="w-full px-5 py-4 flex items-center justify-between font-semibold text-left">
            <span>4. Preferred Cuisine</span>
            {activeSection === 3 ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
          </button>
          
          {activeSection === 3 && (
            <div className="px-5 pb-5 pt-0 animate-in slide-in-from-top-2 duration-200">
              <Select
                label="Preferred Cuisine"
                options={cuisineOptions}
                value={cuisine}
                onChange={(e) => setCuisine(e.target.value)}
              />
            </div>
          )}
        </div>

        <div className="pt-6">
          <Button onClick={onFinish}>
            Finish Onboarding
          </Button>
          <div className="text-center mt-3">
             <button onClick={onFinish} className="text-sm text-gray-500 hover:text-black underline decoration-gray-300 underline-offset-4">
               Skip for now
             </button>
          </div>
        </div>

      </div>
    </div>
  );
};