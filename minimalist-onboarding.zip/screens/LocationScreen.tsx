import React, { useState } from 'react';
import { LocationCard } from '../components/LocationCard';
import { LocationOption } from '../types';
import { MapPin } from 'lucide-react';

const LOCATIONS: LocationOption[] = [
  {
    id: 'london',
    name: 'London',
    // Image of Tower Bridge
    imageUrl: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=800&q=80',
  },
  {
    id: 'mumbai',
    name: 'Mumbai',
    // Image of Gateway of India
    imageUrl: 'https://images.unsplash.com/photo-1566552881560-0be862a7c445?auto=format&fit=crop&w=800&q=80',
  },
];

interface LocationScreenProps {
  onNext: () => void;
}

export const LocationScreen: React.FC<LocationScreenProps> = ({ onNext }) => {
  const [selectedLocationId, setSelectedLocationId] = useState<string | null>(null);

  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto px-6 py-8 animate-in fade-in slide-in-from-right-8 duration-700">
      <div className="text-center mb-8">
        <div className="w-12 h-12 bg-white rounded-full border border-black flex items-center justify-center mx-auto mb-4">
          <MapPin className="text-black" size={24} />
        </div>
        <h2 className="text-2xl font-bold text-black mb-2">Select Your Location</h2>
        <p className="text-gray-600">
          We are currently working in these {LOCATIONS.length} locations.
        </p>
      </div>

      <div className="w-full grid grid-cols-1 gap-4 mb-8">
        {LOCATIONS.map((location) => (
          <LocationCard
            key={location.id}
            location={location}
            isSelected={selectedLocationId === location.id}
            onSelect={setSelectedLocationId}
          />
        ))}
      </div>

      {selectedLocationId && (
        <div className="w-full animate-in fade-in duration-300">
          <button 
            onClick={onNext}
            className="w-full py-4 bg-black text-white rounded-lg font-medium hover:bg-gray-800 transition-colors"
          >
            Continue to {LOCATIONS.find(l => l.id === selectedLocationId)?.name}
          </button>
        </div>
      )}
    </div>
  );
};