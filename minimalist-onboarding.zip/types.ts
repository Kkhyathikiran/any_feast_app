export interface LocationOption {
  id: string;
  name: string;
  imageUrl: string;
}

export type AppStep = 'login' | 'location' | 'age' | 'bmi' | 'goal' | 'settings' | 'diet' | 'congrats';

export type BmiUnit = 'metric' | 'imperial';

export interface BmiResult {
  bmi: number;
  category: string;
}

export interface GoalOption {
  id: string;
  title: string;
  imageUrl: string;
}